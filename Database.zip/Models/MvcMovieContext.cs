using Microsoft.EntityFrameworkCore;

namespace sql_6.Models
{
    public class MvcMovieContext : DbContext
    {
        public MvcMovieContext (DbContextOptions<MvcMovieContext> options)
            : base(options)
        {
        }

        public DbSet<sql_6.Models.Movie> Movie { get; set; }
    }
}